package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.exceptions.CustomerNotFoundException;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

@SpringBootTest
class CustomerTests {

	@Autowired
	CustomerService customerService;

	@Test
	public void testAddCustomer() {
		Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune",
				"Patna", "SE1");
		String result = customerService.addCustomer(customer);

		assertEquals("Customer added Successfully", result);
	}

	@Test
	public void testUpdateCustomer() {
		Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune",
				"Pune", "SE1");
		customer.setEmail("y@gmail.com");
		String result = customerService.updateCustomer(customer);

		assertEquals("Customer updated Successfully", result);
	}

	@Test
	public void testDeleteCustomer() {
		long customerId = 1;
		String result = customerService.deleteCustomer(customerId);

		assertEquals("Customer Deleted Successfully", result);
	}

//	check here
	@Test
	public void testGetCustomer() {

		Customer expectedCustomer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(),
				"Pune", "Pune", "SE1");

		customerService.addCustomer(expectedCustomer);
		
		Customer actualCustomer = customerService.getCustomer(1);
	
		assertNotNull(actualCustomer);
		assertEquals(expectedCustomer.getId(), actualCustomer.getId());

	}

	@Test
	public void testGetAllCustomers() {

		Customer customer1 = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune",
				"Pune", "SE1");
		Customer customer2 = new Customer(2, "Gautam", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune",
				"Pune", "SE1");

		customerService.addCustomer(customer1);
		customerService.addCustomer(customer2);

		List<Customer> actualCustomers = customerService.getAllCustomers();

	    assertEquals(2, actualCustomers.size());
	}

	@Test
	public void testGetCustomerNotFound() {
		long nonExistentCustomerId = 999;
		try {
			Customer actualCustomer = customerService.getCustomer(nonExistentCustomerId);
			fail("Expected CustomerNotFoundException, but got customer: " + actualCustomer);
		} catch (CustomerNotFoundException e) {
			assertEquals("Customer not found for : " + nonExistentCustomerId, e.getMessage());
		}
	}

}